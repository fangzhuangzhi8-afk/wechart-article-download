# WeChat Article Download Skill

[![OpenClaw Skill](https://img.shields.io/badge/OpenClaw-Skill-blue.svg)](https://clawhub.ai)
[![Python 3.8+](https://img.shields.io/badge/Python-3.8+-green.svg)](https://python.org)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)

一个强大的微信公众号文章下载工具，能够从微信公众号文章网站读取所有文字以及图表内容，并生成完整的Word文件。

## ✨ 功能特性

### 🎯 核心功能
- **完整内容提取**：提取文章标题、作者、发布时间、公众号名称
- **图表批量下载**：自动识别并下载所有图片/图表
- **Word文档生成**：生成格式规范的Word文档（.docx格式）
- **图文位置保持**：保持图表在原文中的位置关系
- **批量处理支持**：支持单个URL和批量URL处理

### 🔧 增强功能 (2026-04-20 增强版)
- **增强标题提取**：15种标题提取模式，解决标题提取为空的问题
- **增强内容提取**：提取所有可能的内容区域，解决内容不完整的问题
- **修复图片位置**：精确检测图片标签位置，保持图文对应
- **优化图片提取**：支持多种图片URL格式，优化去重逻辑
- **详细调试信息**：显示提取到的内容长度和图片位置

## 🚀 快速开始

### 安装依赖
```bash
pip install requests python-docx
```

### 基本使用
```bash
# 单个文章下载
python scripts/download_wechat_article.py https://mp.weixin.qq.com/s/xxx

# 指定输出目录
python scripts/download_wechat_article.py https://mp.weixin.qq.com/s/xxx ./output

# 使用命令行接口
python scripts/wechat_article_cli.py https://mp.weixin.qq.com/s/xxx
```

### 作为OpenClaw技能使用
1. 将本目录复制到OpenClaw工作空间的`skills/`目录
2. 在OpenClaw中调用`wechart-article-download`技能

## 📁 项目结构

```
wechart-article-download/
├── SKILL.md                    # OpenClaw技能定义文件
├── README.md                   # 项目说明文档
├── GITHUB_README.md           # GitHub README (本文件)
├── scripts/                    # Python脚本目录
│   ├── download_wechat_article.py      # 主脚本 (增强版)
│   ├── download_wechat_article_enhanced.py  # 增强版备份
│   ├── wechat_article_cli.py           # 命令行接口
│   ├── improved_extractor.py           # 改进版提取器
│   └── test_skill.py                   # 测试脚本
├── references/                 # 参考文档
│   ├── wechat_article_patterns.md     # 微信公众号HTML模式
│   └── word_formatting_guide.md       # Word格式指南
└── assets/                     # 资源文件
    └── README.md               # 资源说明
```

## 🔧 技术细节

### 增强标题提取
使用15种标题提取模式，包括：
- Meta标签提取 (`og:title`, `title`)
- Title标签提取
- JavaScript变量提取 (`msg_title`)
- HTML内容提取 (`h1`, `h2`, `rich_media_title`)
- 文章开头提取

### 修复图片位置
1. **精确检测**：使用正则表达式查找所有`<img>`标签位置
2. **智能分割**：按图片位置分割内容为文本和图片段落
3. **保持对应**：图片插入在对应的文字描述旁边
4. **顺序保持**：保持原文的阅读顺序和结构

### 优化图片提取
1. **多种URL格式**：支持`data-src`、`src`和直接URL
2. **URL去重**：基于基础URL去重，避免重复下载
3. **尺寸优化**：自动选择最佳尺寸（优先使用`/640`）
4. **错误处理**：完整的错误捕获和恢复机制

## 📊 性能指标

### 实际案例测试
| 测试文章 | 内容长度 | 图片数量 | 图片位置 | 文件大小 |
|----------|----------|----------|----------|----------|
| 机器人SoC芯片方案精选 | 70,525字符 | 7个 | 64个位置 | 752KB |
| 欧洲新能源电网问题 | 37,542字符 | 6个 | 12个位置 | 1.1MB |

### 处理流程
```
1. 获取HTML内容
2. 提取标题 (15种模式)
3. 提取内容 (所有section和div)
4. 提取图片URL (多种格式)
5. 下载图片 (去重和优化)
6. 创建Word文档 (保持图文对应)
7. 保存元数据
```

## 🛠️ 故障排除

### 常见问题

#### Q1: 标题提取为空
**解决方案**：技能使用15种标题提取模式，通常可以从JavaScript变量或meta标签中提取到标题。

#### Q2: 内容不完整
**解决方案**：技能提取所有section和包含中文的div，确保获取完整内容。

#### Q3: 图片位置不对
**解决方案**：技能精确检测图片标签位置，按位置分割内容，保持图文对应。

#### Q4: 图片提取不完整
**解决方案**：技能支持多种图片URL格式，优化去重逻辑，处理尺寸后缀问题。

### 调试模式
```bash
# 设置环境变量
export WECHAT_VERBOSE=1

# 运行脚本
python scripts/download_wechat_article.py <URL>
```

## 📝 版本历史

### 2026-04-20 增强版
**修复的问题**：
1. **标题提取为空**：使用15种标题提取模式
2. **内容不完整**：提取所有section和包含中文的div
3. **图片位置不对**：精确检测图片标签位置，保持图文对应
4. **图片提取不完整**：支持多种图片URL格式，优化去重逻辑

**增强功能**：
1. 添加详细的调试信息
2. 改进错误处理和恢复机制
3. 优化Word文档格式
4. 添加元数据保存功能

## 🤝 贡献指南

欢迎提交Issue和Pull Request！

### 开发环境设置
```bash
# 克隆仓库
git clone https://github.com/yourusername/wechart-article-download.git

# 安装开发依赖
pip install -r requirements-dev.txt

# 运行测试
python scripts/test_skill.py
```

### 代码规范
- 遵循PEP 8编码规范
- 添加适当的注释和文档
- 编写单元测试
- 更新版本历史

## 📄 许可证

本项目采用MIT许可证 - 查看 [LICENSE](LICENSE) 文件了解详情。

## 🙏 致谢

感谢所有贡献者和用户的支持！

## 📞 联系方式

如有问题或建议，请通过以下方式联系：
- GitHub Issues: [项目Issues页面](https://github.com/yourusername/wechart-article-download/issues)
- Email: your.email@example.com

---

**⭐ 如果这个项目对你有帮助，请给个Star！**