---
name: wechart-article-download
description: 微信公众号文章下载技能 - 从微信公众号文章网站读取所有文字以及图表内容，并生成完整的Word文件。当用户需要下载微信公众号文章、提取文章所有文字和图表、生成包含完整内容的Word文档时使用此技能。支持批量下载、图表位置保持、完整内容提取等功能。
---

# Wechart Article Download

## 概述

微信公众号文章下载技能提供完整的微信公众号文章内容提取和下载功能。能够从微信公众号文章网站读取所有文字信息，下载所有图表（不止20个），将图表放在正确位置，并生成完整的Word文件。

## 核心功能

### 1. 完整内容提取
- 提取文章标题、作者、发布时间、公众号名称
- 提取所有文字内容，保持原文格式和段落结构
- 支持多种HTML结构模式，提高提取成功率

### 2. 图表批量下载
- 自动识别文章中的所有图片/图表URL
- 批量下载所有图表（支持jpg、png、gif、webp等格式）
- 图表去重和完整性检查
- 支持断点续传和错误恢复

### 3. Word文档生成
- 生成格式规范的Word文档（.docx格式）
- 保持图表在原文中的位置关系
- 添加图表编号和标题
- 使用标准中文字体（微软雅黑、宋体）

### 4. 批量处理
- 支持单个URL处理
- 支持批量URL处理（从文件读取）
- 为每个文章创建独立的输出目录
- 生成完整的处理报告和元数据

## 版本历史

### 2026-04-20 增强版更新
**修复的问题：**
1. **标题提取为空**：使用15种标题提取模式，解决标题提取失败问题
2. **内容不完整**：提取所有section和包含中文的div，解决内容缺失问题
3. **图片位置不对**：精确检测图片标签位置，保持图文对应
4. **图片提取不完整**：支持多种图片URL格式，优化去重逻辑

**增强功能：**
1. **增强标题提取**：支持meta标签、title标签、JavaScript变量等多种提取模式
2. **增强内容提取**：提取所有可能的内容区域，包括section标签
3. **修复图片位置**：按图片标签位置分割内容，保持图文对应关系
4. **添加调试信息**：显示提取到的内容长度、图片标签位置和分割段落数量

### 快速开始

### 安装依赖
```bash
pip install requests python-docx
```

### 基本使用
```bash
# 单个文章下载
python scripts/download_wechat_article.py https://mp.weixin.qq.com/s/xxx

# 指定输出目录
python scripts/download_wechat_article.py https://mp.weixin.qq.com/s/xxx ./output

# 使用命令行接口
python scripts/wechat_article_cli.py https://mp.weixin.qq.com/s/xxx
```

### 批量处理
```bash
# 创建URL列表文件
echo "https://mp.weixin.qq.com/s/xxx1" > urls.txt
echo "https://mp.weixin.qq.com/s/xxx2" >> urls.txt

# 批量下载
python scripts/wechat_article_cli.py --batch urls.txt
```

## 工作流程

### 步骤1：提取文章内容
1. 发送HTTP请求获取文章HTML
2. 提取标题、作者、发布时间等元数据
3. 提取正文内容，清理HTML标签
4. 保持段落结构和文本格式

### 步骤2：提取图表URL
1. 从HTML内容中查找所有图片标签
2. 提取图片URL（支持src和data-src属性）
3. URL去重和验证
4. 记录图表在原文中的位置

### 步骤3：下载图表
1. 创建图表保存目录
2. 批量下载所有图表文件
3. 处理下载失败和网络问题
4. 保存图表元数据（文件名、大小、原始URL）

### 步骤4：生成Word文档
1. 创建Word文档，设置标题和元数据
2. 按原文顺序插入文字内容
3. 在图表位置插入对应的图片
4. 添加图表编号和统计信息
5. 保存文档并验证完整性

## 使用场景

### 场景1：研究资料收集
用户需要收集微信公众号上的行业分析报告，包含大量图表和数据。

**用户请求示例**：
- "下载这篇液冷泵阀行业深度研究报告的所有文字和图表"
- "把这篇文章做成完整的Word文档，图表要齐全"
- "批量下载这几篇储能行业分析文章"

### 场景2：内容存档
用户需要将重要的微信公众号文章完整保存，包括所有图表。

**用户请求示例**：
- "保存这篇技术文章，图表要全部下载"
- "把这篇文章导出为Word，图表放在正确位置"
- "存档这篇市场分析报告"

### 场景3：内容分析
用户需要分析微信公众号文章的内容和图表数据。

**用户请求示例**：
- "提取这篇文章的所有图表进行分析"
- "生成包含完整图表的报告文档"
- "批量处理这些文章，统计图表数量"

## 输出文件结构

```
wechat_article_output/
├── 文章标题_20260420_153000.docx    # Word文档
├── charts/                          # 图表目录
│   ├── chart_001_abc123.jpg        # 图表文件
│   ├── chart_002_def456.png
│   └── ...
├── metadata_20260420_153000.json   # 元数据文件
└── processing_log.txt              # 处理日志
```

## 错误处理

### 常见问题及解决方案

#### 1. 内容提取失败
- **问题**：无法提取文章内容
- **原因**：HTML结构变化、访问限制
- **解决方案**：尝试多个提取模式，检查网络连接

#### 2. 图表下载失败
- **问题**：部分图表无法下载
- **原因**：URL过期、访问限制、网络问题
- **解决方案**：记录失败图表，继续处理其他内容

#### 3. Word生成失败
- **问题**：无法生成Word文档
- **原因**：文件权限、磁盘空间、依赖缺失
- **解决方案**：检查目录权限，确保python-docx安装正确

#### 4. 编码问题
- **问题**：中文乱码
- **原因**：编码不一致
- **解决方案**：强制使用UTF-8编码，清理非法字符

## 技能资源

### scripts/ - 脚本文件
包含执行微信公众号文章下载的核心脚本：

1. **`download_wechat_article.py`** - 主脚本
   - 完整的文章下载流程
   - 包含内容提取、图表下载、Word生成
   - 支持错误处理和进度反馈

2. **`wechat_article_cli.py`** - 命令行接口
   - 用户友好的命令行界面
   - 支持单个URL和批量处理
   - 提供详细的使用说明和示例

**使用方法**：
```bash
# 直接使用主脚本
python scripts/download_wechat_article.py <URL>

# 使用命令行接口
python scripts/wechat_article_cli.py <URL> [输出目录]
```

### references/ - 参考文档
提供技术参考和最佳实践：

1. **`wechat_article_patterns.md`** - 微信公众号文章HTML模式
   - 常见的HTML结构模式
   - 图片URL提取策略
   - 内容提取的最佳实践

2. **`word_formatting_guide.md`** - Word格式指南
   - 文档结构和样式设置
   - 字体和颜色方案
   - 图表处理和页面布局

**使用场景**：
- 当需要了解微信公众号文章的结构时
- 当需要自定义Word文档格式时
- 当遇到提取或格式问题时

### assets/ - 资产文件
包含模板和示例文件：

1. **`README.md`** - 资产文件说明
   - 目录结构和文件说明
   - 模板使用指南
   - 字体和示例文件

**可选内容**：
- `word_template.docx` - Word模板文件
- `fonts/` - 字体文件目录
- `images/` - 示例图片目录

## 技术细节

### 依赖要求
```python
# 必需依赖
requests>=2.28.0      # HTTP请求库
python-docx>=0.8.11   # Word文档处理

# 可选依赖
chardet>=5.0.0        # 编码检测
Pillow>=9.0.0         # 图片处理
```

### 环境要求
- Python 3.7+
- 网络连接（用于访问微信公众号）
- 磁盘空间（用于保存图表和Word文档）
- 文件写入权限

### 性能考虑
1. **网络请求**：设置合理的超时时间和重试机制
2. **内存使用**：流式下载大文件，避免内存溢出
3. **磁盘空间**：定期清理临时文件，管理输出目录
4. **并发处理**：批量处理时控制并发数量

## 测试和验证

### 单元测试
```bash
# 测试内容提取
python -c "from scripts.download_wechat_article import extract_article_content; print('测试通过')"

# 测试图表下载
python -c "from scripts.download_wechat_article import extract_chart_urls; print('测试通过')"

# 测试Word生成
python -c "from scripts.download_wechat_article import create_word_document; print('测试通过')"
```

### 集成测试
```bash
# 使用示例URL测试完整流程
python scripts/wechat_article_cli.py --test

# 验证输出文件
python -c "import os; print('文件存在:', os.path.exists('output.docx'))"
```

### 质量检查
1. **内容完整性**：检查是否提取了所有文字
2. **图表完整性**：检查是否下载了所有图表
3. **格式正确性**：检查Word文档格式是否正确
4. **错误处理**：测试各种错误情况的处理

## 故障排除

### 常见问题

#### Q1: 无法提取文章内容
**可能原因**：
- 网络连接问题
- URL格式错误
- 微信公众号访问限制

**解决方案**：
- 检查网络连接
- 验证URL是否正确
- 尝试使用浏览器访问确认文章可读

#### Q2: 图表下载不完整
**可能原因**：
- 图片URL过期
- 访问频率限制
- 网络不稳定

**解决方案**：
- 检查下载日志
- 尝试手动下载单个图片
- 调整请求间隔时间

#### Q3: Word文档格式错误
**可能原因**：
- python-docx版本不兼容
- 字体缺失
- 文件权限问题

**解决方案**：
- 更新python-docx到最新版本
- 安装所需字体
- 检查输出目录权限

#### Q4: 中文乱码
**可能原因**：
- 编码设置错误
- 字体不支持中文
- 文本清理问题

**解决方案**：
- 强制使用UTF-8编码
- 使用支持中文的字体
- 清理非法字符

#### Q5: 标题提取为空
**可能原因**：
- 微信公众号使用JavaScript动态加载标题
- 标题被隐藏或加密
- HTML结构变化

**解决方案**：
- 使用增强版标题提取（15种提取模式）
- 检查HTML中的meta标签和JavaScript变量
- 从文章内容中提取可能的标题

#### Q6: 内容不完整
**可能原因**：
- 内容被分散到多个div或section中
- 只提取了主要区域的内容
- 防爬机制导致内容隐藏

**解决方案**：
- 使用增强版内容提取（提取所有section和div）
- 检查多个内容区域
- 合并所有提取到的内容部分

#### Q7: 图片位置不对
**可能原因**：
- 图片标签位置检测失败
- 内容分割逻辑不正确
- 图片插入顺序错乱

**解决方案**：
- 使用精确的图片标签位置检测
- 按图片位置分割内容
- 保持图文对应关系

#### Q8: 图片提取不完整
**可能原因**：
- 图片URL格式变化
- 重复URL未去重
- 尺寸后缀问题（/0 vs /640）

**解决方案**：
- 支持多种图片URL格式
- 优化URL去重逻辑
- 处理尺寸后缀问题

### 调试模式
启用详细日志输出：
```bash
# 设置环境变量
export WECHAT_VERBOSE=1

# 运行脚本
python scripts/download_wechat_article.py <URL>
```

### 实际案例修复经验 (2026-04-20)

**案例：机器人SoC芯片方案精选文章**
- **URL**: `https://mp.weixin.qq.com/s/oMZs8j7ds-HuPBz9o5sJ4g`
- **问题**: 标题提取为空，内容不完整，图片位置不对
- **修复方案**:
  1. **标题提取**: 使用15种标题提取模式，从JavaScript变量中提取到完整标题
  2. **内容提取**: 提取所有section标签，内容从2,340字符增加到68,080字符
  3. **图片位置**: 检测34个图片标签位置，分割为43个段落，保持图文对应
  4. **图片提取**: 找到7个唯一图片URL，全部下载成功

**关键修复代码**:
```python
# 增强版标题提取
title_patterns = [
    r'<meta[^>]*property="og:title"[^>]*content="([^"]+)"',
    r'<title[^>]*>(.*?)</title>',
    r'var\s+msg_title\s*=\s*["\'](.*?)["\']',
    # ... 共15种模式
]

# 修复图片位置
img_pattern = r'(<img[^>]*>)'
img_matches = list(re.finditer(img_pattern, content_html, re.IGNORECASE))

# 按图片位置分割内容
segments = []
last_pos = 0
for match in img_matches:
    img_tag = match.group(1)
    start_pos = match.start()
    end_pos = match.end()
    
    # 添加图片前的文本
    if start_pos > last_pos:
        text_segment = content_html[last_pos:start_pos]
        segments.append(('text', text_segment))
    
    # 添加图片
    segments.append(('image', img_tag))
    last_pos = end_pos
```

### 调试模式
启用详细日志输出：
```bash
# 设置环境变量
export WECHAT_VERBOSE=1

# 运行脚本
python scripts/download_wechat_article.py <URL>
```

## 更新和维护

### 版本历史
- **v1.0.0** (2026-04-20): 初始版本发布
  - 基本文章内容提取
  - 图表批量下载
  - Word文档生成

### 未来改进
1. **功能增强**
   - 支持更多文章平台
   - 添加PDF输出格式
   - 支持自定义模板

2. **性能优化**
   - 并行下载图表
   - 缓存已下载内容
   - 增量更新

3. **用户体验**
   - 图形用户界面
   - 浏览器插件
   - API服务

### 贡献指南
欢迎提交问题和改进建议：
1. 在GitHub仓库创建Issue
2. 提交Pull Request
3. 提供测试用例
4. 更新文档

## 许可证
本技能基于MIT许可证开源发布。详见LICENSE文件。
