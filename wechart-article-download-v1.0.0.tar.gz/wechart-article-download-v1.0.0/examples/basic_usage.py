#!/usr/bin/env python3
"""
WeChat Article Download Skill - 使用示例
"""

import sys
import os

# 添加脚本目录到路径
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'scripts'))

from download_wechat_article import main as download_main

def example_single_article():
    """单个文章下载示例"""
    print("=" * 60)
    print("示例1: 单个文章下载")
    print("=" * 60)
    
    # 示例URL
    url = "https://mp.weixin.qq.com/s/0Eun0OS0ZOyfqgEtH66rww"
    output_dir = "./example_output"
    
    print(f"文章URL: {url}")
    print(f"输出目录: {output_dir}")
    
    # 模拟命令行参数
    sys.argv = ['download_wechat_article.py', url, output_dir]
    
    try:
        download_main()
        print("✅ 下载完成！")
    except SystemExit:
        pass  # 正常退出
    except Exception as e:
        print(f"❌ 下载失败: {e}")

def example_batch_download():
    """批量下载示例"""
    print("\n" + "=" * 60)
    print("示例2: 批量文章下载")
    print("=" * 60)
    
    # 创建URL列表文件
    urls = [
        "https://mp.weixin.qq.com/s/0Eun0OS0ZOyfqgEtH66rww",
        "https://mp.weixin.qq.com/s/oMZs8j7ds-HuPBz9o5sJ4g",
    ]
    
    url_file = "urls.txt"
    with open(url_file, 'w', encoding='utf-8') as f:
        for url in urls:
            f.write(url + '\n')
    
    print(f"URL列表文件: {url_file}")
    print(f"包含 {len(urls)} 个文章")
    
    # 使用命令行接口进行批量下载
    print("\n使用以下命令进行批量下载:")
    print(f"python scripts/wechat_article_cli.py --batch {url_file}")
    
    # 清理临时文件
    if os.path.exists(url_file):
        os.remove(url_file)

def example_as_module():
    """作为Python模块使用示例"""
    print("\n" + "=" * 60)
    print("示例3: 作为Python模块使用")
    print("=" * 60)
    
    from download_wechat_article import (
        extract_article_content,
        extract_chart_urls,
        download_charts,
        create_word_document,
        save_metadata
    )
    
    url = "https://mp.weixin.qq.com/s/0Eun0OS0ZOyfqgEtH66rww"
    output_dir = "./module_output"
    
    print("步骤1: 提取文章内容")
    article_data = extract_article_content(url)
    
    if article_data['success']:
        print(f"  标题: {article_data['title']}")
        print(f"  作者: {article_data['author']}")
        print(f"  内容长度: {len(article_data['content_html'])} 字符")
        
        print("\n步骤2: 提取图表URL")
        chart_urls = extract_chart_urls(article_data['content_html'])
        print(f"  找到 {len(chart_urls)} 个图表URL")
        
        print("\n步骤3: 下载图表")
        downloaded_charts = download_charts(chart_urls, output_dir)
        print(f"  下载 {len(downloaded_charts)} 个图表")
        
        print("\n步骤4: 创建Word文档")
        word_file = create_word_document(article_data, downloaded_charts, 
                                        os.path.join(output_dir, "output.docx"))
        if word_file:
            print(f"  Word文档: {word_file}")
        
        print("\n步骤5: 保存元数据")
        metadata_file = save_metadata(article_data, downloaded_charts, output_dir)
        if metadata_file:
            print(f"  元数据文件: {metadata_file}")
        
        print("\n✅ 模块使用示例完成！")
    else:
        print(f"❌ 文章提取失败: {article_data.get('error')}")

def main():
    """主函数"""
    print("WeChat Article Download Skill - 使用示例")
    print("=" * 60)
    
    # 创建示例输出目录
    os.makedirs("./example_output", exist_ok=True)
    os.makedirs("./module_output", exist_ok=True)
    
    # 运行示例
    example_single_article()
    example_batch_download()
    example_as_module()
    
    print("\n" + "=" * 60)
    print("所有示例完成！")
    print("=" * 60)
    
    # 清理输出目录
    import shutil
    if os.path.exists("./example_output"):
        shutil.rmtree("./example_output")
    if os.path.exists("./module_output"):
        shutil.rmtree("./module_output")
    
    print("已清理临时输出目录")

if __name__ == "__main__":
    main()