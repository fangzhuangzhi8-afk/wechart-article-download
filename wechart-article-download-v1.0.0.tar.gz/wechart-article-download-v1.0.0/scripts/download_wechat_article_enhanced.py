#!/usr/bin/env python3
"""
微信公众号文章下载器 - 增强版主脚本
功能：从微信公众号文章网站读取所有文字以及图表内容，并生成完整的Word文件
版本：2026-04-20 增强版 - 修复图片位置问题，保持图文对应

更新内容：
1. 增强标题提取：支持多种标题提取模式
2. 增强内容提取：提取所有可能的内容区域
3. 修复图片位置：精确检测图片标签位置，保持图文对应
4. 添加调试信息：显示提取到的内容长度和图片位置
"""

import os
import sys
import re
import requests
from datetime import datetime
from urllib.parse import urljoin
import json
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
import time
import hashlib

def extract_article_content_enhanced(url):
    """
    增强版：从微信公众号文章URL提取文字内容
    修复问题：标题提取为空，内容不完整
    """
    try:
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'zh-CN,zh;q=0.8,zh-TW;q=0.7,zh-HK;q=0.5,en-US;q=0.3,en;q=0.2',
            'Accept-Encoding': 'gzip, deflate, br',
        }
        
        print(f"正在获取文章内容: {url}")
        response = requests.get(url, headers=headers, timeout=30)
        response.encoding = 'utf-8'
        html_content = response.text
        
        # ==================== 增强版标题提取 ====================
        # 尝试多种标题提取方法，解决标题提取为空的问题
        title_patterns = [
            # 从meta标签提取
            r'<meta[^>]*property="og:title"[^>]*content="([^"]+)"',
            r'<meta[^>]*name="title"[^>]*content="([^"]+)"',
            
            # 从title标签提取
            r'<title[^>]*>(.*?)</title>',
            
            # 从JavaScript变量提取
            r'var\s+msg_title\s*=\s*["\'](.*?)["\']',
            r'msg_title\s*=\s*["\'](.*?)["\']',
            
            # 从HTML内容提取
            r'<h1[^>]*>(.*?)</h1>',
            r'<h2[^>]*>(.*?)</h2>',
            r'<div[^>]*class="rich_media_title"[^>]*>(.*?)</div>',
            
            # 从文章开头提取
            r'<section[^>]*>.*?<strong[^>]*>(.*?)</strong>',
        ]
        
        title = "未获取到标题"
        for pattern in title_patterns:
            match = re.search(pattern, html_content, re.IGNORECASE | re.DOTALL)
            if match:
                extracted_title = match.group(1).strip()
                extracted_title = re.sub(r'<[^>]+>', '', extracted_title)
                extracted_title = re.sub(r'\s+', ' ', extracted_title)
                extracted_title = re.sub(r'[\\/*?:"<>|]', '', extracted_title)
                
                if extracted_title and len(extracted_title) > 3:
                    title = extracted_title
                    print(f"  使用模式找到标题: {title[:50]}...")
                    break
        
        # ==================== 增强版内容提取 ====================
        # 提取所有可能的内容区域，解决内容不完整的问题
        content_patterns = [
            r'<div[^>]*class="rich_media_content"[^>]*>(.*?)</div>',
            r'<div[^>]*id="js_content"[^>]*>(.*?)</div>',
            r'<div[^>]*class="article-content"[^>]*>(.*?)</div>',
            r'<div[^>]*class="content"[^>]*>(.*?)</div>',
            
            # 新增：提取所有section标签内容
            r'<section[^>]*>(.*?)</section>',
            
            # 新增：提取所有包含中文的div
            r'<div[^>]*>.*?[\u4e00-\u9fff].*?</div>',
        ]
        
        content_html = ""
        for pattern in content_patterns:
            matches = re.findall(pattern, html_content, re.IGNORECASE | re.DOTALL)
            for match in matches:
                if match and len(match) > 100:  # 只保留有内容的部分
                    content_html += "\n\n" + match
        
        # 如果没找到内容，使用整个HTML
        if not content_html.strip():
            content_html = html_content
        
        print(f"  提取到内容长度: {len(content_html):,} 字符")
        
        # ==================== 提取作者信息 ====================
        author = "未知作者"
        author_match = re.search(r'<meta[^>]*name="author"[^>]*content="([^"]+)"', html_content, re.IGNORECASE)
        if author_match:
            author = author_match.group(1).strip()
        
        # ==================== 提取公众号信息 ====================
        wechat_name = "未知公众号"
        wechat_match = re.search(r'<meta[^>]*property="og:site_name"[^>]*content="([^"]+)"', html_content, re.IGNORECASE)
        if wechat_match:
            wechat_name = wechat_match.group(1).strip()
        
        # ==================== 提取发布日期 ====================
        publish_date = datetime.now().strftime('%Y-%m-%d')
        date_match = re.search(r'<meta[^>]*property="article:published_time"[^>]*content="([^"]+)"', html_content, re.IGNORECASE)
        if date_match:
            date_str = date_match.group(1).strip()
            date_match2 = re.search(r'(\d{4}-\d{2}-\d{2})', date_str)
            if date_match2:
                publish_date = date_match2.group(1)
        
        return {
            'title': title,
            'url': url,
            'publish_date': publish_date,
            'author': author,
            'wechat_name': wechat_name,
            'content_html': content_html,
            'success': True
        }
        
    except Exception as e:
        print(f"提取文章内容失败: {e}")
        import traceback
        traceback.print_exc()
        return {
            'success': False,
            'error': str(e)
        }

def extract_chart_urls_enhanced(content_html):
    """
    增强版：从文章内容中提取图表URL
    修复问题：图片URL提取不完整
    """
    try:
        # ==================== 增强版图片URL提取 ====================
        # 支持多种图片URL格式，解决图片提取不完整的问题
        img_patterns = [
            r'data-src="(https://mmbiz\.qpic\.cn/[^"]+)"',
            r'src="(https://mmbiz\.qpic\.cn/[^"]+)"',
            r'https://mmbiz\.qpic\.cn/[^\s"\']+',
        ]
        
        all_urls = []
        for pattern in img_patterns:
            matches = re.findall(pattern, content_html, re.IGNORECASE)
            all_urls.extend(matches)
        
        print(f"  找到 {len(all_urls)} 个可能的图片URL")
        
        # ==================== URL去重和优化 ====================
        # 解决重复URL和尺寸问题
        unique_urls = []
        base_urls = set()
        
        for url in all_urls:
            # 清理URL
            url = url.split('?')[0]  # 移除查询参数
            
            # 提取基础URL（移除尺寸后缀）
            base_url = re.sub(r'/(0|640|300|1080)(\?|$)', '', url)
            
            if base_url not in base_urls:
                base_urls.add(base_url)
                # 使用640尺寸的URL（如果可用）
                if '/640' in url:
                    unique_urls.append(url)
                elif '/0' in url:
                    # 将/0替换为/640
                    unique_urls.append(url.replace('/0', '/640'))
                else:
                    unique_urls.append(url)
        
        print(f"  去重后保留 {len(unique_urls)} 个唯一URL")
        
        # 显示前几个URL
        for i, url in enumerate(unique_urls[:3]):
            print(f"    {i+1}. {url[:80]}...")
        
        return unique_urls
        
    except Exception as e:
        print(f"提取图表URL失败: {e}")
        return []

def download_charts_enhanced(chart_urls, output_dir):
    """
    增强版：下载图表文件
    """
    try:
        charts_dir = os.path.join(output_dir, "charts")
        if not os.path.exists(charts_dir):
            os.makedirs(charts_dir)
        
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        }
        
        downloaded_charts = []
        
        for i, url in enumerate(chart_urls):
            try:
                # 生成唯一文件名
                url_hash = hashlib.md5(url.encode()).hexdigest()[:8]
                filename = f"chart_{i+1:03d}_{url_hash}.jpg"
                filepath = os.path.join(charts_dir, filename)
                
                print(f"正在下载图表 {i+1}/{len(chart_urls)}: {url[:60]}...")
                
                img_response = requests.get(url, headers=headers, timeout=15)
                
                if img_response.status_code == 200 and 'image' in img_response.headers.get('content-type', ''):
                    with open(filepath, 'wb') as f:
                        f.write(img_response.content)
                    
                    downloaded_charts.append({
                        'filename': filename,
                        'filepath': filepath,
                        'size': len(img_response.content),
                        'url': url,
                        'index': i
                    })
                    
                    print(f"  已保存: {filename} ({len(img_response.content):,} bytes)")
                else:
                    print(f"  跳过: 不是有效的图片 (状态码: {img_response.status_code})")
                    
            except Exception as e:
                print(f"  下载失败: {e}")
        
        print(f"成功下载 {len(downloaded_charts)}/{len(chart_urls)} 个图表")
        return downloaded_charts
        
    except Exception as e:
        print(f"下载图表失败: {e}")
        return []

def create_word_document_enhanced(article_data, downloaded_charts, output_path):
    """
    增强版：创建Word文档
    修复问题：图片位置不对，图文分离
    """
    try:
        # 创建文档
        doc = Document()
        
        # 设置默认字体
        style = doc.styles['Normal']
        style.font.name = '微软雅黑'
        style.font.size = Pt(11)
        
        # 1. 添加标题
        title_para = doc.add_heading(article_data['title'], level=1)
        title_para.alignment = WD_ALIGN_PARAGRAPH.CENTER
        
        # 2. 添加元数据
        meta_text = f"来源：{article_data['wechat_name']} | 作者：{article_data['author']} | 发布日期：{article_data['publish_date']}"
        meta_para = doc.add_paragraph(meta_text)
        meta_para.alignment = WD_ALIGN_PARAGRAPH.CENTER
        
        # 3. 添加原文链接
        link_para = doc.add_paragraph(f"原文链接：{article_data['url']}")
        link_para.alignment = WD_ALIGN_PARAGRAPH.CENTER
        
        doc.add_paragraph()  # 空行
        
        # ==================== 增强版内容处理 ====================
        # 修复图片位置问题，保持图文对应
        content_html = article_data['content_html']
        
        print(f"  处理内容HTML: {len(content_html):,} 字符")
        
        # 1. 首先找到所有图片标签的位置
        img_pattern = r'(<img[^>]*>)'
        img_matches = list(re.finditer(img_pattern, content_html, re.IGNORECASE))
        
        print(f"  找到 {len(img_matches)} 个图片标签位置")
        
        # 2. 按图片位置分割内容
        segments = []
        last_pos = 0
        
        for match in img_matches:
            img_tag = match.group(1)
            start_pos = match.start()
            end_pos = match.end()
            
            # 添加图片前的文本
            if start_pos > last_pos:
                text_segment = content_html[last_pos:start_pos]
                segments.append(('text', text_segment))
            
            # 添加图片
            segments.append(('image', img_tag))
            last_pos = end_pos
        
        # 添加最后一段文本
        if last_pos < len(content_html):
            text_segment = content_html[last_pos:]
            segments.append(('text', text_segment))
        
        print(f"  分割为 {len(segments)} 个段落")
        
        # 3. 处理每个段落
        image_index = 0
        
        for seg_type, seg_content in segments:
            if seg_type == 'text':
                # 处理文本段落
                clean_text = re.sub(r'<[^>]+>', '', seg_content).strip()
                clean_text = re.sub(r'\s+', ' ', clean_text)
                
                if clean_text:
                    # 按换行分割
                    lines = [line.strip() for line in clean_text.split('\n') if line.strip()]
                    for line in lines:
                        if line:
                            # 检查是否是标题
                            if (len(line) < 100 and 
                                (re.search(r'(芯片|方案|产品|特性|总结|简介|概述|厂商|领域|技术)$', line) or
                                 re.search(r'^【', line) or
                                 re.search(r'^[一二三四五六七八九十]、', line) or
                                 re.search(r'^[0-9]+\.', line))):
                                doc.add_heading(line, level=2)
                            else:
                                doc.add_paragraph(line)
            
            elif seg_type == 'image':
                # 处理图片
                if image_index < len(downloaded_charts):
                    chart = downloaded_charts[image_index]
                    try:
                        # 添加图片标题
                        chart_title = doc.add_paragraph()
                        chart_title_run = chart_title.add_run(f"图表 {image_index + 1}")
                        chart_title_run.font.size = Pt(10)
                        chart_title_run.font.italic = True
                        chart_title_run.font.color.rgb = RGBColor(80, 80, 80)
                        
                        # 插入图片
                        doc.add_picture(chart['filepath'], width=Inches(6))
                        
                        # 添加空行
                        doc.add_paragraph()
                        
                        image_index += 1
                    except Exception as e:
                        print(f"  插入图表失败: {e}")
                        doc.add_paragraph(f"[图表 {image_index + 1} 插入失败: {chart['filename']}]")
                        image_index += 1
        
        # 4. 图表统计
        if downloaded_charts:
            doc.add_page_break()
            stats_heading = doc.add_heading('图表统计', level=1)
            
            stats_text = f"本文共包含 {len(downloaded_charts)} 个图表，已全部嵌入到文档中。"
            doc.add_paragraph(stats_text)
            
            # 图表列表
            for i, chart in enumerate(downloaded_charts):
                doc.add_paragraph(f"图表 {i+1}: {chart['filename']} ({chart['size']} bytes)")
        
        # 5. 保存文档
        doc.save(output_path)
        print(f"Word文档已保存: {output_path} ({os.path.getsize(output_path):,} bytes)")
        
        return output_path
        
    except Exception as e:
        print(f"创建Word文档失败: {e}")
        import traceback
        traceback.print_exc()
        return None

def save_metadata(article_data, downloaded_charts, output_dir):
    """
    保存元数据文件
    """
    try:
        metadata = {
            'title': article_data['title'],
            'url': article_data['url'],
            'publish_date': article_data['publish_date'],
            'author': article_data['author'],
            'wechat_name': article_data['wechat_name'],
            'content_length': len(article_data['content_html']),
            'chart_count': len(downloaded_charts),
            'charts': [
                {
                    'filename': chart['filename'],
                    'size': chart['size'],
                    'url': chart['url'],
                    'index': chart['index']
                }
                for chart in downloaded_charts
            ],
            'processing_time': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'version': '2026-04-20 增强版'
        }
        
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        metadata_file = os.path.join(output_dir, f"metadata_{timestamp}.json")
        
        with open(metadata_file, 'w', encoding='utf-8') as f:
            json.dump(metadata, f, ensure_ascii=False, indent=2)
        
        print(f"元数据已保存: {metadata_file}")
        
        return metadata_file
        
    except Exception as e:
        print(f"保存元数据失败: {e}")
        return None

def main():
    """
    主函数
    """
    if len(sys.argv) < 2:
        print("=" * 60)
        print("微信公众号文章下载器 - 增强版 (2026-04-20)")
        print("=" * 60)
        print("使用方法: python download_wechat_article_enhanced.py <微信公众号文章URL> [输出目录]")
        print("示例: python download_wechat_article_enhanced.py https://mp.weixin.qq.com/s/xxx ./output")
        print("\n增强功能:")
        print("1. 增强标题提取：支持多种标题提取模式")
        print("2. 增强内容提取：提取所有可能的内容区域")
        print("3. 修复图片位置：精确检测图片标签位置，保持图文对应")
        print("4. 添加调试信息：显示提取到的内容长度和图片位置")
        print("=" * 60)
        sys.exit(1)
    
    url = sys.argv[1]
    output_dir = sys.argv[2] if len(sys.argv) > 2 else "./wechat_article_output"
    
    # 创建输出目录
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
    
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    
    print("=" * 60)
    print("微信公众号文章下载器 - 增强版 (2026-04-20)")
    print("=" * 60)
    
    # 步骤1: 提取文章内容
    print("\n步骤1: 提取文章内容...")
    article_data = extract_article_content_enhanced(url)
    
    if not article_data['success']:
        print(f"提取失败: {article_data.get('error', '未知错误')}")
        sys.exit(1)
    
    print(f"文章标题: {article_data['title']}")
    print(f"公众号: {article_data['wechat_name']}")
    print(f"作者: {article_data['author']}")
    print(f"发布日期: {article_data['publish_date']}")
    
    # 步骤2: 提取图表URL
    print("\n步骤2: 提取图表URL...")
    chart_urls = extract_chart_urls_enhanced(article_data['content_html'])
    
    if not chart_urls:
        print("警告: 未找到图表URL")
    
    # 步骤3: 下载图表
    print("\n步骤3: 下载图表...")
    downloaded_charts = download_charts_enhanced(chart_urls, output_dir)
    
    # 步骤4: 创建Word文档
    print("\n步骤4: 创建Word文档...")
    
    # 生成Word文件名
    safe_title = re.sub(r'[\\/*?:"<>|]', '', article_data['title'])[:50]
    word_filename = f"{safe_title}_{timestamp}.docx"
    word_filepath = os.path.join(output_dir, word_filename)
    
    word_file = create_word_document_enhanced(article_data, downloaded_charts, word_filepath)
    
    if not word_file:
        print("创建Word文档失败")
        sys.exit(1)
    
    # 步骤5: 保存元数据
    print("\n步骤5: 保存元数据...")
    metadata_file = save_metadata(article_data, downloaded_charts, output_dir)
    
    print("=" * 60)
    print("✅ 下载完成！")
    print(f"文章标题: {article_data['title']}")
    print(f"图表数量: {len(downloaded_charts)}/{len(chart_urls)}")
    print(f"Word文件: {word_file}")
    print(f"图表目录: {os.path.join(output_dir, 'charts')}")
    if metadata_file:
        print(f"元数据: {metadata_file}")
    print("=" * 60)

if __name__ == "__main__":
    main()