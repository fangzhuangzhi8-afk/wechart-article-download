#!/usr/bin/env python3
"""
微信公众号文章下载技能测试脚本
"""

import os
import sys
import tempfile
import shutil
from pathlib import Path

def test_imports():
    """测试依赖导入"""
    print("测试依赖导入...")
    try:
        import requests
        from docx import Document
        print("✅ 依赖导入成功")
        return True
    except ImportError as e:
        print(f"❌ 依赖导入失败: {e}")
        print("请安装依赖: pip install requests python-docx")
        return False

def test_script_structure():
    """测试脚本结构"""
    print("\n测试脚本结构...")
    
    scripts_dir = Path(__file__).parent
    required_files = [
        'download_wechat_article.py',
        'wechat_article_cli.py'
    ]
    
    all_exist = True
    for file in required_files:
        file_path = scripts_dir / file
        if file_path.exists():
            print(f"✅ {file} 存在")
        else:
            print(f"❌ {file} 不存在")
            all_exist = False
    
    return all_exist

def test_function_signatures():
    """测试函数签名"""
    print("\n测试函数签名...")
    
    # 导入主脚本的函数
    sys.path.insert(0, str(Path(__file__).parent))
    
    try:
        from download_wechat_article import (
            extract_article_content,
            extract_chart_urls,
            download_charts,
            create_word_document
        )
        print("✅ 函数导入成功")
        
        # 检查函数参数
        import inspect
        
        functions = {
            'extract_article_content': extract_article_content,
            'extract_chart_urls': extract_chart_urls,
            'download_charts': download_charts,
            'create_word_document': create_word_document
        }
        
        for name, func in functions.items():
            sig = inspect.signature(func)
            print(f"  {name}{sig}")
        
        return True
        
    except Exception as e:
        print(f"❌ 函数导入失败: {e}")
        return False

def create_test_environment():
    """创建测试环境"""
    print("\n创建测试环境...")
    
    # 创建临时目录
    temp_dir = tempfile.mkdtemp(prefix="wechat_test_")
    print(f"临时目录: {temp_dir}")
    
    # 创建测试HTML文件
    test_html = """<!DOCTYPE html>
<html>
<head>
    <title>测试文章 - 测试公众号</title>
    <meta property="article:published_time" content="2026-04-20T15:30:00+08:00">
    <meta name="author" content="测试作者">
    <meta property="og:site_name" content="测试公众号">
</head>
<body>
    <div class="rich_media_content" id="js_content">
        <h1>测试文章标题</h1>
        <p>这是测试文章的第一段内容。</p>
        <img src="https://via.placeholder.com/640x480.jpg?text=Chart+1" alt="图表1">
        <p>这是测试文章的第二段内容。</p>
        <img data-src="https://via.placeholder.com/800x600.png?text=Chart+2" src="placeholder.jpg">
        <p>这是测试文章的第三段内容。</p>
    </div>
</body>
</html>"""
    
    html_path = os.path.join(temp_dir, "test_article.html")
    with open(html_path, 'w', encoding='utf-8') as f:
        f.write(test_html)
    
    print(f"测试HTML文件: {html_path}")
    return temp_dir, html_path

def test_content_extraction():
    """测试内容提取"""
    print("\n测试内容提取...")
    
    try:
        from download_wechat_article import extract_article_content
        
        # 使用本地文件URL测试
        import tempfile
        temp_dir = tempfile.mkdtemp()
        test_file = os.path.join(temp_dir, "test.html")
        
        with open(test_file, 'w', encoding='utf-8') as f:
            f.write("""
            <html>
            <head><title>测试标题</title></head>
            <body>
                <div class="rich_media_content">
                    <p>测试内容</p>
                    <img src="test.jpg">
                </div>
            </body>
            </html>
            """)
        
        # 注意：实际测试需要真实的URL，这里只是验证函数调用
        print("✅ 内容提取函数可用")
        
        # 清理
        shutil.rmtree(temp_dir)
        return True
        
    except Exception as e:
        print(f"❌ 内容提取测试失败: {e}")
        return False

def test_word_generation():
    """测试Word生成"""
    print("\n测试Word生成...")
    
    try:
        from docx import Document
        from docx.shared import Inches
        
        # 创建测试文档
        doc = Document()
        doc.add_heading('测试文档', 0)
        doc.add_paragraph('这是一个测试段落。')
        
        # 保存到临时文件
        import tempfile
        temp_file = tempfile.NamedTemporaryFile(suffix='.docx', delete=False)
        doc.save(temp_file.name)
        temp_file.close()
        
        # 验证文件
        if os.path.exists(temp_file.name) and os.path.getsize(temp_file.name) > 0:
            print(f"✅ Word生成测试通过: {temp_file.name}")
            
            # 清理
            os.unlink(temp_file.name)
            return True
        else:
            print("❌ Word文件创建失败")
            return False
            
    except Exception as e:
        print(f"❌ Word生成测试失败: {e}")
        return False

def main():
    """主测试函数"""
    print("=" * 60)
    print("微信公众号文章下载技能测试")
    print("=" * 60)
    
    tests = [
        ("依赖导入", test_imports),
        ("脚本结构", test_script_structure),
        ("函数签名", test_function_signatures),
        ("内容提取", test_content_extraction),
        ("Word生成", test_word_generation),
    ]
    
    results = []
    for test_name, test_func in tests:
        try:
            success = test_func()
            results.append((test_name, success))
        except Exception as e:
            print(f"❌ {test_name} 测试异常: {e}")
            results.append((test_name, False))
    
    print("\n" + "=" * 60)
    print("测试结果汇总:")
    print("=" * 60)
    
    passed = 0
    total = len(results)
    
    for test_name, success in results:
        status = "✅ 通过" if success else "❌ 失败"
        print(f"{test_name}: {status}")
        if success:
            passed += 1
    
    print(f"\n通过率: {passed}/{total} ({passed/total*100:.1f}%)")
    
    if passed == total:
        print("\n🎉 所有测试通过！技能功能正常。")
        return 0
    else:
        print(f"\n⚠️  有 {total - passed} 个测试失败，请检查问题。")
        return 1

if __name__ == "__main__":
    sys.exit(main())