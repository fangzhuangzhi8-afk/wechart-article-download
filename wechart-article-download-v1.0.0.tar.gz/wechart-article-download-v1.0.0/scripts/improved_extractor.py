#!/usr/bin/env python3
"""
改进的微信公众号文章提取器
专门处理微信公众号的防爬机制和复杂HTML结构
"""

import re
import json
from datetime import datetime

def extract_wechat_title(html_content):
    """
    改进的标题提取函数
    尝试多种方式提取微信公众号文章标题
    """
    title_patterns = [
        # 1. 标准title标签
        r'<title[^>]*>(.*?)</title>',
        
        # 2. Open Graph标题
        r'<meta[^>]*property="og:title"[^>]*content="([^"]+)"',
        
        # 3. 微信公众号特定标题
        r'<meta[^>]*name="title"[^>]*content="([^"]+)"',
        
        # 4. 文章内容中的标题
        r'<h1[^>]*>(.*?)</h1>',
        r'<h2[^>]*>(.*?)</h2>',
        
        # 5. 微信公众号rich_media_title
        r'<div[^>]*class="rich_media_title"[^>]*>(.*?)</div>',
        
        # 6. 从JavaScript中提取
        r'var\s+msg_title\s*=\s*["\'](.*?)["\']',
        r'title\s*:\s*["\'](.*?)["\']',
    ]
    
    for pattern in title_patterns:
        match = re.search(pattern, html_content, re.IGNORECASE | re.DOTALL)
        if match:
            title = match.group(1).strip()
            # 清理标题
            title = re.sub(r'<[^>]+>', '', title)  # 移除HTML标签
            title = re.sub(r'\s+', ' ', title)     # 合并空格
            title = re.sub(r'[\\/*?:"<>|]', '', title)  # 移除非法字符
            
            # 如果标题包含公众号名称，尝试提取纯标题
            if ' - ' in title:
                parts = title.split(' - ')
                if len(parts) > 1:
                    title = parts[0].strip()
            
            if title and len(title) > 3:  # 确保标题有意义
                return title
    
    return "未获取到标题"

def extract_wechat_content(html_content):
    """
    改进的内容提取函数
    更智能地提取微信公众号文章内容
    """
    # 尝试多种内容容器
    content_patterns = [
        # 1. 微信公众号标准容器
        r'<div[^>]*id="js_content"[^>]*>(.*?)</div>',
        r'<div[^>]*class="rich_media_content"[^>]*>(.*?)</div>',
        
        # 2. 文章内容容器
        r'<article[^>]*>(.*?)</article>',
        r'<div[^>]*class="article-content"[^>]*>(.*?)</div>',
        r'<div[^>]*class="content"[^>]*>(.*?)</div>',
        
        # 3. 微信公众号特定结构
        r'<section[^>]*data-role="paragraph"[^>]*>(.*?)</section>',
        
        # 4. 如果以上都失败，提取body中的主要内容
        r'<body[^>]*>(.*?)</body>',
    ]
    
    content_html = ""
    for pattern in content_patterns:
        match = re.search(pattern, html_content, re.IGNORECASE | re.DOTALL)
        if match:
            content_html = match.group(1)
            break
    
    if not content_html:
        # 如果没有找到特定容器，使用整个HTML
        content_html = html_content
    
    return content_html

def clean_html_content(html_content):
    """
    智能清理HTML内容，保留重要文本和结构
    """
    if not html_content:
        return ""
    
    # 1. 保留重要的HTML标签
    # 替换段落标签为换行
    html_content = re.sub(r'</p>', '\n\n', html_content, flags=re.IGNORECASE)
    html_content = re.sub(r'<br\s*/?>', '\n', html_content, flags=re.IGNORECASE)
    html_content = re.sub(r'</div>', '\n', html_content, flags=re.IGNORECASE)
    
    # 2. 保留标题标签
    html_content = re.sub(r'</h1>', '\n\n', html_content, flags=re.IGNORECASE)
    html_content = re.sub(r'</h2>', '\n\n', html_content, flags=re.IGNORECASE)
    html_content = re.sub(r'</h3>', '\n\n', html_content, flags=re.IGNORECASE)
    
    # 3. 移除脚本和样式
    html_content = re.sub(r'<script[^>]*>.*?</script>', '', html_content, flags=re.IGNORECASE | re.DOTALL)
    html_content = re.sub(r'<style[^>]*>.*?</style>', '', html_content, flags=re.IGNORECASE | re.DOTALL)
    
    # 4. 移除注释
    html_content = re.sub(r'<!--.*?-->', '', html_content, flags=re.DOTALL)
    
    # 5. 移除属性但保留标签内容
    # 先处理span标签（微信公众号常用）
    html_content = re.sub(r'<span[^>]*>(.*?)</span>', r'\1', html_content, flags=re.IGNORECASE | re.DOTALL)
    
    # 6. 处理其他内联标签
    html_content = re.sub(r'<strong[^>]*>(.*?)</strong>', r'**\1**', html_content, flags=re.IGNORECASE | re.DOTALL)
    html_content = re.sub(r'<b[^>]*>(.*?)</b>', r'**\1**', html_content, flags=re.IGNORECASE | re.DOTALL)
    html_content = re.sub(r'<em[^>]*>(.*?)</em>', r'*\1*', html_content, flags=re.IGNORECASE | re.DOTALL)
    html_content = re.sub(r'<i[^>]*>(.*?)</i>', r'*\1*', html_content, flags=re.IGNORECASE | re.DOTALL)
    
    # 7. 移除剩余的HTML标签
    html_content = re.sub(r'<[^>]+>', '', html_content)
    
    # 8. 清理空白字符
    html_content = re.sub(r'\n\s*\n\s*\n+', '\n\n', html_content)
    html_content = re.sub(r'[ \t]+', ' ', html_content)
    html_content = html_content.strip()
    
    return html_content

def extract_metadata(html_content):
    """
    提取文章元数据
    """
    metadata = {
        'publish_date': datetime.now().strftime('%Y-%m-%d'),
        'author': '未知作者',
        'wechat_name': '未知公众号'
    }
    
    # 提取发布日期
    date_patterns = [
        r'<meta[^>]*property="article:published_time"[^>]*content="([^"]+)"',
        r'<meta[^>]*name="publish_date"[^>]*content="([^"]+)"',
        r'发布日期[:：]\s*([0-9]{4}-[0-9]{2}-[0-9]{2})',
    ]
    
    for pattern in date_patterns:
        match = re.search(pattern, html_content, re.IGNORECASE)
        if match:
            metadata['publish_date'] = match.group(1)
            break
    
    # 提取作者
    author_patterns = [
        r'<meta[^>]*name="author"[^>]*content="([^"]+)"',
        r'作者[:：]\s*([^<>\n]+)',
    ]
    
    for pattern in author_patterns:
        match = re.search(pattern, html_content, re.IGNORECASE)
        if match:
            metadata['author'] = match.group(1)
            break
    
    # 提取公众号名称
    wechat_patterns = [
        r'<meta[^>]*property="og:site_name"[^>]*content="([^"]+)"',
        r'公众号[:：]\s*([^<>\n]+)',
    ]
    
    for pattern in wechat_patterns:
        match = re.search(pattern, html_content, re.IGNORECASE)
        if match:
            metadata['wechat_name'] = match.group(1)
            break
    
    return metadata

def test_extraction():
    """
    测试提取功能
    """
    # 读取之前下载的HTML内容
    import os
    metadata_path = '/home/dennyfang/.openclaw/workspace/wechat_article_output/metadata_20260420_221419.json'
    
    if os.path.exists(metadata_path):
        with open(metadata_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        html_content = data['article']['content_html']
        
        print("测试改进的提取器:")
        print("=" * 60)
        
        # 提取标题
        title = extract_wechat_title(html_content)
        print(f"提取到的标题: {title}")
        
        # 提取内容
        content_html = extract_wechat_content(html_content)
        print(f"提取到的HTML内容长度: {len(content_html)} 字符")
        
        # 清理内容
        clean_content = clean_html_content(content_html)
        print(f"清理后的内容长度: {len(clean_content)} 字符")
        
        # 显示前500字符
        print(f"\n清理后的内容前500字符:")
        print("-" * 60)
        print(clean_content[:500])
        print("-" * 60)
        
        # 提取元数据
        metadata = extract_metadata(html_content)
        print(f"\n提取到的元数据:")
        print(f"发布日期: {metadata['publish_date']}")
        print(f"作者: {metadata['author']}")
        print(f"公众号: {metadata['wechat_name']}")
        
        return True
    else:
        print(f"元数据文件不存在: {metadata_path}")
        return False

if __name__ == "__main__":
    test_extraction()