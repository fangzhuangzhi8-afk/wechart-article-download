#!/usr/bin/env python3
"""
微信公众号文章下载器 - 命令行接口
"""

import argparse
import sys
import os
from download_wechat_article import main as download_main

def main():
    parser = argparse.ArgumentParser(
        description='微信公众号文章下载器 - 下载文章文字和所有图表，生成Word文档',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  %(prog)s https://mp.weixin.qq.com/s/xxx
  %(prog)s https://mp.weixin.qq.com/s/xxx ./output
  %(prog)s --batch urls.txt
  
功能特点:
  1. 提取文章所有文字内容
  2. 下载所有图表（不止20个）
  3. 图表放在正确位置
  4. 生成完整Word文件
        """
    )
    
    parser.add_argument('url', nargs='?', help='微信公众号文章URL')
    parser.add_argument('output_dir', nargs='?', default='./wechat_article_output',
                       help='输出目录（默认: ./wechat_article_output）')
    parser.add_argument('--batch', '-b', help='批量处理文件，包含多个URL（每行一个）')
    parser.add_argument('--verbose', '-v', action='store_true', help='详细输出模式')
    parser.add_argument('--timeout', '-t', type=int, default=30,
                       help='请求超时时间（秒，默认: 30）')
    parser.add_argument('--max-charts', '-m', type=int, default=0,
                       help='最大图表下载数量（0表示无限制，默认: 0）')
    
    args = parser.parse_args()
    
    if not args.url and not args.batch:
        parser.print_help()
        sys.exit(1)
    
    # 设置环境变量
    if args.verbose:
        os.environ['WECHAT_VERBOSE'] = '1'
    
    if args.batch:
        # 批量处理模式
        print(f"批量处理模式: {args.batch}")
        try:
            with open(args.batch, 'r', encoding='utf-8') as f:
                urls = [line.strip() for line in f if line.strip()]
            
            print(f"找到 {len(urls)} 个URL")
            
            for i, url in enumerate(urls):
                print(f"\n处理第 {i+1}/{len(urls)} 个URL: {url}")
                try:
                    # 为每个URL创建单独的输出目录
                    import re
                    from datetime import datetime
                    
                    safe_url = re.sub(r'[^a-zA-Z0-9]', '_', url)[:50]
                    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
                    batch_output_dir = os.path.join(args.output_dir, f"batch_{timestamp}_{safe_url}")
                    
                    # 调用主函数
                    sys.argv = ['download_wechat_article.py', url, batch_output_dir]
                    download_main()
                    
                except Exception as e:
                    print(f"处理失败: {e}")
                    continue
                    
        except Exception as e:
            print(f"批量处理失败: {e}")
            sys.exit(1)
            
    else:
        # 单个URL处理模式
        print(f"处理单个URL: {args.url}")
        sys.argv = ['download_wechat_article.py', args.url, args.output_dir]
        download_main()

if __name__ == "__main__":
    main()