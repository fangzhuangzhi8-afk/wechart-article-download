# 资产文件说明

## 目录结构

```
assets/
├── word_template.docx      # Word模板文件（可选）
├── fonts/                  # 字体文件（可选）
│   ├── simsun.ttf         # 宋体字体
│   └── msyh.ttf           # 微软雅黑字体
└── images/                 # 示例图片（可选）
    ├── wechat_logo.png    # 微信公众号logo
    └── chart_example.jpg  # 图表示例
```

## Word模板使用

### 1. 创建模板
如果需要使用自定义模板，可以：
1. 在Microsoft Word中创建模板文件
2. 设置好样式（标题、正文、图表等）
3. 保存为`word_template.docx`
4. 放在此目录中

### 2. 模板内容
模板应包含以下样式定义：
- 标题1（H1）：文章主标题
- 标题2（H2）：章节标题
- 正文：普通段落
- 图表标题：图表说明文字
- 引用：原文链接等

### 3. 使用模板
在代码中加载模板：
```python
from docx import Document

# 使用模板创建文档
template_path = "assets/word_template.docx"
doc = Document(template_path)
```

## 字体文件

### 1. 中文字体
如果需要确保字体一致性，可以包含：
- `simsun.ttf`：宋体（正文使用）
- `msyh.ttf`：微软雅黑（标题使用）

### 2. 安装字体
在生成Word文档前，确保系统已安装所需字体：
```python
import platform

def check_fonts():
    system = platform.system()
    if system == "Windows":
        # Windows字体目录
        font_dir = "C:/Windows/Fonts/"
    elif system == "Linux":
        # Linux字体目录
        font_dir = "/usr/share/fonts/"
    elif system == "Darwin":  # macOS
        font_dir = "/Library/Fonts/"
    
    # 检查字体是否存在
    required_fonts = ["simsun.ttf", "msyh.ttf"]
    for font in required_fonts:
        font_path = os.path.join(font_dir, font)
        if os.path.exists(font_path):
            print(f"字体已安装: {font}")
        else:
            print(f"警告：字体未安装: {font}")
```

## 示例文件

### 1. 示例微信公众号文章
`example_wechat_article.html` - 用于测试的示例文章

### 2. 示例图表
`chart_example.jpg` - 用于测试的示例图表

### 3. 使用示例
```python
# 使用示例文件进行测试
example_html = "assets/example_wechat_article.html"
example_image = "assets/chart_example.jpg"

# 测试提取功能
with open(example_html, 'r', encoding='utf-8') as f:
    html_content = f.read()

# 测试图片插入
doc.add_picture(example_image, width=Inches(6))
```

## 注意事项

### 1. 文件大小
- 避免在资产中包含大文件
- 图片应使用压缩格式（jpg, png）
- 模板文件应保持简洁

### 2. 版权问题
- 确保所有资产文件有合法使用权
- 避免包含受版权保护的内容
- 使用开源或自己创建的资源

### 3. 跨平台兼容性
- 字体文件可能需要不同格式（ttf, otf）
- 图片格式应广泛支持（jpg, png）
- 模板文件应使用标准docx格式