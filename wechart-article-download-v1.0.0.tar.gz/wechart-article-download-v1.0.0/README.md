# Wechart Article Download Skill

微信公众号文章下载技能 - 从微信公众号文章网站读取所有文字以及图表内容，并生成完整的Word文件。

## 功能特点

### 🎯 核心功能
1. **完整内容提取** - 提取文章所有文字内容，保持原文格式
2. **图表批量下载** - 下载所有图表（不止20个），支持多种图片格式
3. **位置保持** - 图表放在原文中的正确位置
4. **Word生成** - 生成格式规范的Word文档（.docx格式）

### 🔧 技术特性
- 支持单个URL和批量处理
- 自动识别微信公众号文章HTML结构
- 完整的错误处理和进度反馈
- 生成处理报告和元数据文件

## 快速开始

### 安装依赖
```bash
pip install requests python-docx
```

### 基本使用
```bash
# 使用主脚本
python scripts/download_wechat_article.py https://mp.weixin.qq.com/s/xxx

# 使用命令行接口
python scripts/wechat_article_cli.py https://mp.weixin.qq.com/s/xxx ./output
```

### 批量处理
```bash
# 创建URL列表文件
echo "https://mp.weixin.qq.com/s/xxx1" > urls.txt
echo "https://mp.weixin.qq.com/s/xxx2" >> urls.txt

# 批量下载
python scripts/wechat_article_cli.py --batch urls.txt
```

## 输出示例

### 文件结构
```
wechat_article_output/
├── 液冷泵阀行业深度研究报告_20260420_153000.docx
├── charts/
│   ├── chart_001_abc123.jpg
│   ├── chart_002_def456.png
│   └── ...
├── metadata_20260420_153000.json
└── processing_log.txt
```

### Word文档内容
1. **标题部分**
   - 文章标题（24磅，加粗，居中）
   - 文章信息（来源、作者、发布日期）
   - 原文链接

2. **正文内容**
   - 所有文字内容，保持原文段落结构
   - 图表按原文位置插入
   - 图表自动编号

3. **统计部分**
   - 图表数量统计
   - 处理时间信息

## 使用场景

### 场景1：研究资料收集
```bash
# 下载行业分析报告
python scripts/wechat_article_cli.py https://mp.weixin.qq.com/s/液冷泵阀行业报告
```

### 场景2：内容存档
```bash
# 保存重要技术文章
python scripts/wechat_article_cli.py https://mp.weixin.qq.com/s/技术文章 --output ./archives
```

### 场景3：批量处理
```bash
# 批量下载多篇文章
python scripts/wechat_article_cli.py --batch research_articles.txt
```

## 配置选项

### 命令行参数
```bash
python scripts/wechat_article_cli.py <URL> [输出目录] [选项]

选项:
  --batch, -b FILE     批量处理文件（每行一个URL）
  --verbose, -v        详细输出模式
  --timeout, -t SEC    请求超时时间（默认: 30秒）
  --max-charts, -m NUM 最大图表下载数量（0表示无限制）
```

### 环境变量
```bash
# 启用详细日志
export WECHAT_VERBOSE=1

# 设置代理
export HTTP_PROXY=http://proxy.example.com:8080
export HTTPS_PROXY=http://proxy.example.com:8080
```

## 故障排除

### 常见问题

#### Q1: 无法提取文章内容
**解决方案**：
- 检查网络连接
- 验证URL是否正确
- 尝试使用浏览器访问确认文章可读

#### Q2: 图表下载不完整
**解决方案**：
- 检查下载日志
- 调整请求间隔时间
- 手动验证图片URL是否有效

#### Q3: Word文档格式错误
**解决方案**：
- 更新python-docx到最新版本
- 安装所需字体（微软雅黑、宋体）
- 检查输出目录权限

### 调试模式
```bash
# 启用详细输出
export WECHAT_VERBOSE=1
python scripts/download_wechat_article.py <URL>
```

## 技术细节

### 依赖要求
- Python 3.7+
- requests>=2.28.0
- python-docx>=0.8.11

### 支持的文件格式
- 输入：微信公众号文章URL
- 输出：Word文档（.docx）、图片文件（.jpg, .png, .gif等）、JSON元数据

### 性能考虑
- 网络请求：默认30秒超时，支持重试
- 内存使用：流式下载大文件
- 磁盘空间：自动管理临时文件

## 开发指南

### 项目结构
```
wechart-article-download/
├── SKILL.md                    # 技能主文档
├── scripts/                    # 脚本文件
│   ├── download_wechat_article.py  # 主脚本
│   ├── wechat_article_cli.py       # 命令行接口
│   └── test_skill.py               # 测试脚本
├── references/                 # 参考文档
│   ├── wechat_article_patterns.md  # HTML模式参考
│   └── word_formatting_guide.md    # Word格式指南
└── assets/                     # 资产文件
    └── README.md              # 资产说明
```

### 扩展开发
1. **添加新的文章平台支持**
   - 在`extract_article_content`函数中添加新的HTML模式
   - 更新`wechat_article_patterns.md`文档

2. **自定义输出格式**
   - 修改`create_word_document`函数
   - 使用自定义模板（放在`assets/`目录）

3. **性能优化**
   - 实现并行下载
   - 添加缓存机制
   - 优化内存使用

## 许可证

MIT License

## 支持

如有问题或建议，请：
1. 查看`SKILL.md`中的详细文档
2. 运行测试脚本验证功能
3. 提交Issue或Pull Request