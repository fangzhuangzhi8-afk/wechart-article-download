#!/usr/bin/env python3
"""
WeChat Article Download Skill - 安装脚本
"""

from setuptools import setup, find_packages
import os

# 读取README文件
with open('README.md', 'r', encoding='utf-8') as f:
    long_description = f.read()

# 读取版本信息
with open('scripts/download_wechat_article.py', 'r', encoding='utf-8') as f:
    for line in f:
        if '版本：' in line:
            version = line.split('版本：')[-1].strip().split()[0]
            break
    else:
        version = '1.0.0'

setup(
    name='wechat-article-download',
    version=version,
    author='Denny Fang',
    author_email='your.email@example.com',
    description='微信公众号文章下载工具 - 提取所有文字和图表，生成完整Word文档',
    long_description=long_description,
    long_description_content_type='text/markdown',
    url='https://github.com/yourusername/wechart-article-download',
    packages=find_packages(),
    classifiers=[
        'Development Status :: 4 - Beta',
        'Intended Audience :: Developers',
        'Topic :: Software Development :: Libraries :: Python Modules',
        'License :: OSI Approved :: MIT License',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
        'Programming Language :: Python :: 3.12',
    ],
    python_requires='>=3.8',
    install_requires=[
        'requests>=2.28.0',
        'python-docx>=0.8.11',
    ],
    entry_points={
        'console_scripts': [
            'wechat-article-download=scripts.download_wechat_article:main',
            'wechat-download=scripts.wechat_article_cli:main',
        ],
    },
    include_package_data=True,
    keywords='wechat, article, download, word, docx, openclaw, skill',
    project_urls={
        'Bug Reports': 'https://github.com/yourusername/wechart-article-download/issues',
        'Source': 'https://github.com/yourusername/wechart-article-download',
        'Documentation': 'https://github.com/yourusername/wechart-article-download#readme',
    },
)