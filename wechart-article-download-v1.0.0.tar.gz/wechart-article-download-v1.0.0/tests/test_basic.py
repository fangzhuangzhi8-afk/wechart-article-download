#!/usr/bin/env python3
"""
WeChat Article Download Skill - 基本测试
"""

import unittest
import os
import sys
import tempfile
import shutil

# 添加脚本目录到路径
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'scripts'))

from download_wechat_article import (
    extract_article_content,
    extract_chart_urls,
    download_charts,
    create_word_document,
    save_metadata
)

class TestWeChatArticleDownload(unittest.TestCase):
    """微信公众号文章下载测试"""
    
    def setUp(self):
        """测试前准备"""
        self.test_url = "https://mp.weixin.qq.com/s/0Eun0OS0ZOyfqgEtH66rww"
        self.temp_dir = tempfile.mkdtemp(prefix="wechat_test_")
        print(f"测试临时目录: {self.temp_dir}")
    
    def tearDown(self):
        """测试后清理"""
        if os.path.exists(self.temp_dir):
            shutil.rmtree(self.temp_dir)
        print(f"清理临时目录: {self.temp_dir}")
    
    def test_extract_article_content(self):
        """测试文章内容提取"""
        print("\n测试: 文章内容提取")
        
        result = extract_article_content(self.test_url)
        
        self.assertTrue(result['success'], "文章提取应该成功")
        self.assertIn('title', result, "结果应该包含标题")
        self.assertIn('author', result, "结果应该包含作者")
        self.assertIn('content_html', result, "结果应该包含HTML内容")
        
        print(f"  标题: {result['title']}")
        print(f"  作者: {result['author']}")
        print(f"  内容长度: {len(result['content_html'])} 字符")
        
        # 验证标题不是空字符串
        self.assertTrue(len(result['title']) > 0, "标题不应该为空")
        
        # 验证内容不是空字符串
        self.assertTrue(len(result['content_html']) > 0, "内容不应该为空")
    
    def test_extract_chart_urls(self):
        """测试图表URL提取"""
        print("\n测试: 图表URL提取")
        
        # 先提取文章内容
        article_data = extract_article_content(self.test_url)
        self.assertTrue(article_data['success'], "文章提取应该成功")
        
        # 提取图表URL
        chart_urls = extract_chart_urls(article_data['content_html'])
        
        print(f"  找到 {len(chart_urls)} 个图表URL")
        
        # 验证URL格式
        for url in chart_urls[:3]:  # 只检查前3个
            self.assertTrue(url.startswith('http'), f"URL应该以http开头: {url}")
            self.assertIn('mmbiz.qpic.cn', url, f"URL应该包含mmbiz.qpic.cn: {url}")
    
    def test_download_charts(self):
        """测试图表下载"""
        print("\n测试: 图表下载")
        
        # 先提取文章内容和图表URL
        article_data = extract_article_content(self.test_url)
        self.assertTrue(article_data['success'], "文章提取应该成功")
        
        chart_urls = extract_chart_urls(article_data['content_html'])
        
        if chart_urls:  # 如果有图表URL
            # 下载图表
            downloaded_charts = download_charts(chart_urls[:2], self.temp_dir)  # 只下载前2个
            
            print(f"  尝试下载 {len(chart_urls[:2])} 个图表")
            print(f"  成功下载 {len(downloaded_charts)} 个图表")
            
            # 验证下载结果
            for chart in downloaded_charts:
                self.assertIn('filename', chart, "图表信息应该包含文件名")
                self.assertIn('filepath', chart, "图表信息应该包含文件路径")
                self.assertIn('size', chart, "图表信息应该包含文件大小")
                
                # 验证文件存在
                self.assertTrue(os.path.exists(chart['filepath']), 
                              f"图表文件应该存在: {chart['filepath']}")
                
                # 验证文件大小
                self.assertTrue(chart['size'] > 0, 
                              f"图表文件大小应该大于0: {chart['filename']}")
        else:
            print("  没有找到图表URL，跳过下载测试")
    
    def test_create_word_document(self):
        """测试Word文档创建"""
        print("\n测试: Word文档创建")
        
        # 创建测试数据
        article_data = {
            'title': '测试文章标题',
            'url': self.test_url,
            'publish_date': '2026-04-20',
            'author': '测试作者',
            'wechat_name': '测试公众号',
            'content_html': '<p>这是测试内容</p><img src="test.jpg"><p>更多内容</p>',
            'success': True
        }
        
        # 创建测试图表
        test_charts = [
            {
                'filename': 'test_chart_1.jpg',
                'filepath': os.path.join(self.temp_dir, 'test_chart_1.jpg'),
                'size': 1000,
                'url': 'https://mmbiz.qpic.cn/test1.jpg',
                'index': 0
            },
            {
                'filename': 'test_chart_2.jpg',
                'filepath': os.path.join(self.temp_dir, 'test_chart_2.jpg'),
                'size': 2000,
                'url': 'https://mmbiz.qpic.cn/test2.jpg',
                'index': 1
            }
        ]
        
        # 创建测试图片文件
        for chart in test_charts:
            with open(chart['filepath'], 'wb') as f:
                f.write(b'test image data')
        
        # 创建Word文档
        output_path = os.path.join(self.temp_dir, 'test_output.docx')
        result = create_word_document(article_data, test_charts, output_path)
        
        self.assertIsNotNone(result, "Word文档创建应该成功")
        self.assertTrue(os.path.exists(result), "Word文档文件应该存在")
        
        file_size = os.path.getsize(result)
        print(f"  Word文档: {result}")
        print(f"  文件大小: {file_size} 字节")
        
        self.assertTrue(file_size > 0, "Word文档文件大小应该大于0")
    
    def test_save_metadata(self):
        """测试元数据保存"""
        print("\n测试: 元数据保存")
        
        # 创建测试数据
        article_data = {
            'title': '测试文章标题',
            'url': self.test_url,
            'publish_date': '2026-04-20',
            'author': '测试作者',
            'wechat_name': '测试公众号',
            'content_html': '<p>测试内容</p>',
            'success': True
        }
        
        test_charts = [
            {
                'filename': 'test_chart.jpg',
                'size': 1000,
                'url': 'https://mmbiz.qpic.cn/test.jpg',
                'index': 0
            }
        ]
        
        # 保存元数据
        metadata_file = save_metadata(article_data, test_charts, self.temp_dir)
        
        self.assertIsNotNone(metadata_file, "元数据文件应该创建成功")
        self.assertTrue(os.path.exists(metadata_file), "元数据文件应该存在")
        
        print(f"  元数据文件: {metadata_file}")
        
        # 验证文件内容
        import json
        with open(metadata_file, 'r', encoding='utf-8') as f:
            metadata = json.load(f)
        
        self.assertEqual(metadata['title'], article_data['title'], "标题应该匹配")
        self.assertEqual(metadata['author'], article_data['author'], "作者应该匹配")
        self.assertEqual(len(metadata['charts']), len(test_charts), "图表数量应该匹配")

def run_tests():
    """运行所有测试"""
    print("WeChat Article Download Skill - 测试套件")
    print("=" * 60)
    
    # 创建测试套件
    suite = unittest.TestLoader().loadTestsFromTestCase(TestWeChatArticleDownload)
    
    # 运行测试
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)
    
    print("=" * 60)
    print(f"测试结果: {result.testsRun} 个测试运行")
    print(f"失败: {len(result.failures)}")
    print(f"错误: {len(result.errors)}")
    
    return result.wasSuccessful()

if __name__ == "__main__":
    success = run_tests()
    sys.exit(0 if success else 1)