# 微信公众号文章HTML模式参考

## 常见HTML结构模式

### 1. 文章标题
```html
<title>文章标题 - 公众号名称</title>
<!-- 或 -->
<meta property="og:title" content="文章标题" />
```

### 2. 文章正文容器
```html
<!-- 最常见的容器 -->
<div class="rich_media_content" id="js_content">
  <!-- 文章内容在这里 -->
</div>

<!-- 其他可能的容器 -->
<div class="article-content">
<div class="content">
<div id="content">
```

### 3. 图片/图表标签
```html
<!-- 普通图片 -->
<img src="https://mmbiz.qpic.cn/xxx.jpg" data-type="jpeg">

<!-- 延迟加载图片 -->
<img data-src="https://mmbiz.qpic.cn/xxx.jpg" src="placeholder.jpg">

<!-- 带尺寸的图片 -->
<img src="https://mmbiz.qpic.cn/xxx.jpg" data-width="640" data-height="480">

<!-- 背景图片 -->
<div style="background-image: url(https://mmbiz.qpic.cn/xxx.jpg);">
```

### 4. 元数据
```html
<!-- 发布日期 -->
<meta property="article:published_time" content="2026-04-20T15:30:00+08:00">

<!-- 作者 -->
<meta name="author" content="作者名称">

<!-- 公众号名称 -->
<meta property="og:site_name" content="公众号名称">
```

## 图片URL模式

### 1. 腾讯云图片URL
```
https://mmbiz.qpic.cn/mmbiz_jpg/xxx/640?wx_fmt=jpeg
https://mmbiz.qpic.cn/mmbiz_png/xxx/640?wx_fmt=png
https://mmbiz.qpic.cn/mmbiz_gif/xxx/640?wx_fmt=gif
```

### 2. CDN图片URL
```
https://res.wx.qq.com/t/fed_upload/xxx.jpg
https://thirdwx.qlogo.cn/mmopen/xxx/132
```

### 3. 其他图片服务
```
https://image.xxx.com/xxx.jpg
https://cdn.xxx.com/xxx.png
```

## 内容提取策略

### 1. 多模式匹配
使用多个正则表达式模式，按优先级尝试：
1. `class="rich_media_content"`
2. `id="js_content"`
3. `class="article-content"`
4. `class="content"`
5. `<body>`标签内容

### 2. 图片位置保持
保持图片在原文中的位置关系：
1. 按顺序提取所有图片URL
2. 记录每个图片在HTML中的位置
3. 在Word文档中按相同顺序插入图片

### 3. 文本清理
1. 移除HTML标签但保留段落结构
2. 转换`<br>`为换行符
3. 转换`</p>`为段落分隔
4. 清理多余的空格和换行

## 常见问题处理

### 1. 图片下载失败
- 原因：URL过期、访问限制、网络问题
- 处理：记录失败，继续处理其他图片
- 备用方案：在Word中插入占位符文本

### 2. 内容提取不完整
- 原因：HTML结构变化、动态加载
- 处理：尝试多个提取模式
- 备用方案：使用更宽松的正则表达式

### 3. 编码问题
- 原因：页面编码不一致
- 处理：尝试多种编码（utf-8, gbk, gb2312）
- 备用方案：使用chardet自动检测编码

## 最佳实践

### 1. 请求头设置
```python
headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'zh-CN,zh;q=0.8,zh-TW;q=0.7,zh-HK;q=0.5,en-US;q=0.3,en;q=0.2',
    'Accept-Encoding': 'gzip, deflate, br',
}
```

### 2. 错误处理
- 网络请求：设置超时时间，重试机制
- 文件操作：检查目录权限，磁盘空间
- 内存管理：大文件分块处理

### 3. 进度反馈
- 显示当前处理步骤
- 显示已下载/总图表数量
- 显示文件大小和保存位置