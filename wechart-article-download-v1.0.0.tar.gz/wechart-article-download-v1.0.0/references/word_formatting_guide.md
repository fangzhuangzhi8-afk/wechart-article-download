# Word文档格式指南

## 文档结构

### 1. 标题部分
```python
# 主标题
title = doc.add_heading('', level=0)
title_run = title.add_run(article_title)
title_run.font.size = Pt(24)      # 24磅
title_run.font.bold = True        # 加粗
title.alignment = WD_ALIGN_PARAGRAPH.CENTER  # 居中

# 文章信息
info_text = f"来源：{wechat_name} | 作者：{author} | 发布日期：{publish_date}"
info_run.font.size = Pt(11)       # 11磅
info_run.font.color.rgb = RGBColor(100, 100, 100)  # 灰色

# 原文链接
link_run.font.size = Pt(10)       # 10磅
link_run.font.color.rgb = RGBColor(150, 150, 150)  # 浅灰色
```

### 2. 正文格式
```python
# 普通段落
paragraph = doc.add_paragraph(text_content)
# 默认字体：宋体 10.5磅

# 图表标题
chart_title_run.font.size = Pt(10)      # 10磅
chart_title_run.font.italic = True      # 斜体
chart_title_run.font.color.rgb = RGBColor(80, 80, 80)  # 深灰色
```

### 3. 图片插入
```python
# 插入图片
doc.add_picture(image_path, width=Inches(6))  # 宽度6英寸

# 图片居中（通过段落对齐）
paragraph = doc.add_paragraph()
run = paragraph.add_run()
run.add_picture(image_path, width=Inches(6))
paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
```

## 字体设置

### 1. 中文字体
- **主标题**：微软雅黑，24磅，加粗
- **副标题/信息**：微软雅黑，11磅，灰色
- **正文**：宋体，10.5磅
- **图表标题**：宋体，10磅，斜体，深灰色
- **链接**：宋体，10磅，浅灰色

### 2. 英文字体
- 与中文字体保持一致
- 使用相同的字号和颜色

## 颜色方案

### 1. 文本颜色
```python
# 主标题：黑色
RGBColor(0, 0, 0)

# 文章信息：深灰色
RGBColor(100, 100, 100)

# 链接：浅灰色
RGBColor(150, 150, 150)

# 图表标题：中灰色
RGBColor(80, 80, 80)
```

### 2. 强调颜色
```python
# 重要信息：深红色
RGBColor(139, 0, 0)

# 警告信息：橙色
RGBColor(255, 140, 0)

# 成功信息：深绿色
RGBColor(0, 100, 0)
```

## 页面布局

### 1. 页边距
```python
from docx.shared import Inches

# 设置页边距（默认值）
sections = doc.sections
for section in sections:
    section.top_margin = Inches(1)      # 上边距：1英寸
    section.bottom_margin = Inches(1)   # 下边距：1英寸
    section.left_margin = Inches(1.25)  # 左边距：1.25英寸
    section.right_margin = Inches(1.25) # 右边距：1.25英寸
```

### 2. 图片尺寸
```python
# 标准图片宽度
width = Inches(6)      # 6英寸（约15.24厘米）

# 根据图片比例调整高度
# python-docx会自动保持宽高比

# 小图片（图标等）
width = Inches(1)      # 1英寸

# 大图片（重要图表）
width = Inches(7)      # 7英寸
```

## 图表处理

### 1. 图表编号
```python
# 自动编号
for i, chart in enumerate(charts, 1):
    title_text = f"图表 {i}: {chart_description}"
    
# 在文中引用
reference_text = f"如图表 {chart_number} 所示"
```

### 2. 图表位置
```python
# 保持原文中的位置
# 1. 按HTML中的顺序提取图片
# 2. 按相同顺序插入Word
# 3. 在图片位置插入占位符文本

# 图片前后的文本关系
# [前文]
# [图表]
# [后文]
```

### 3. 图表质量
```python
# 下载原始图片（不压缩）
response = requests.get(url, stream=True)

# 保存为高质量格式
# 优先使用原始格式，避免多次压缩

# 检查图片完整性
if os.path.getsize(filepath) < 1024:  # 小于1KB可能是错误
    print(f"警告：图片可能损坏: {filename}")
```

## 文档完整性检查

### 1. 内容完整性
```python
# 检查是否包含所有文字
expected_text_length = len(original_text)
actual_text_length = len(extracted_text)
completeness_ratio = actual_text_length / expected_text_length

if completeness_ratio < 0.9:  # 少于90%
    print("警告：文字内容可能不完整")
```

### 2. 图表完整性
```python
# 检查是否包含所有图表
expected_charts = len(chart_urls)
actual_charts = len(downloaded_charts)
success_rate = actual_charts / expected_charts

if success_rate < 0.8:  # 成功率低于80%
    print("警告：图表下载不完整")
```

### 3. 文件完整性
```python
# 检查Word文件是否可打开
try:
    test_doc = Document(word_path)
    print(f"Word文件验证通过: {word_path}")
except Exception as e:
    print(f"Word文件损坏: {e}")
```

## 性能优化

### 1. 批量处理
```python
# 使用会话保持连接
session = requests.Session()

# 批量下载图片
for url in chart_urls:
    response = session.get(url)
    # 处理响应

# 关闭会话
session.close()
```

### 2. 内存管理
```python
# 流式下载大文件
response = requests.get(url, stream=True)
with open(filename, 'wb') as f:
    for chunk in response.iter_content(chunk_size=8192):
        f.write(chunk)
```

### 3. 错误恢复
```python
# 断点续传
if os.path.exists(partial_file):
    # 从断点继续
    with open(partial_file, 'ab') as f:
        # 继续下载
else:
    # 开始新下载
    with open(partial_file, 'wb') as f:
        # 开始下载
```